#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')
import matplotlib.pyplot as plt


# In[2]:


data=pd.read_csv('Iris.csv')


# In[3]:


data[0:10]


# In[4]:


data.shape


# In[5]:


list(data.columns)


# In[6]:


data['x1'].describe


# In[7]:


data['x1'].describe()


# In[8]:


data['x2'].describe()


# In[9]:


data['x3'].describe()


# In[10]:


data['x4'].describe()


# In[11]:


data['class'].describe()


# In[12]:


plt.hist(data['x1'],bins=30)
plt.ylabel('No of times')
plt.show()


# In[13]:


plt.hist(data['x2'],bins=30)
plt.ylabel('No of times')
plt.show()
plt.hist(data['x3'],bins=30)
plt.ylabel('No of times')
plt.show()
plt.hist(data['x4'],bins=30)
plt.ylabel('No of times')
plt.show()


# In[15]:


plt.boxplot(data['x1'])


# In[18]:


plt.boxplot(data['x2'])


# In[19]:


plt.boxplot(data['x3'])


# In[20]:


plt.boxplot(data['x4'])


# In[21]:


sns.boxplot(x=data['class'],y=data['x1'])

