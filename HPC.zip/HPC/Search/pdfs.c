#include<stdio.h>
#include<mpi.h>
#include<time.h>
#include<stdlib.h>
#define send_data_tag 2001
#define return_data_tag 2002

void printInorder(int *arr,int start,int end)
{ 
   if(start>end)
      return;
   printInorder(arr,start*2+1,end);
   printf("%d ",arr[start]);
   printInorder(arr,start*2+2,end);
}

void buildTree(int *arr,int start,int end,int *tree,int k,int offset,int n)
{
  if(start<=end && k<=n-1)
  {
     int mid = (end+start+1)/2;
     tree[k] = mid+offset;
     buildTree(arr,start,mid-1,tree,k*2+1,offset,n);
     buildTree(arr,mid+1,end,tree,k*2+2,offset,n);
  }
}

int main(int argc,char **argv)
{
   int n=1024;
   int arr[n];
   int tree[n];
   int slaves[n];
   int turn=1;
   int children =4;
   MPI_Status status;
   double start,end;
   int my_id,root_process=0,num_processes,n_recieved;
   MPI_Init(&argc,&argv);
   MPI_Comm_rank(MPI_COMM_WORLD,&my_id);
   MPI_Comm_size(MPI_COMM_WORLD,&num_processes);
   
   start = MPI_Wtime();
   if(my_id==root_process)
   {
     for(turn=1;turn<=children;turn++)
     {
        int offset = (turn-1)*n;
        buildTree(arr,0,n,tree,0,offset,n);
        MPI_Send(&n,1,MPI_INT,turn-1,send_data_tag,MPI_COMM_WORLD);
        MPI_Send(&tree,n,MPI_INT,turn-1,send_data_tag,MPI_COMM_WORLD);
     }
   }
   else
   {
      MPI_Recv(&n_recieved,1,MPI_INT,root_process,send_data_tag,MPI_COMM_WORLD,&status);
      int recieved = n_recieved;
      MPI_Recv(&slaves,n_recieved,MPI_INT,root_process,send_data_tag,MPI_COMM_WORLD,&status);
      printInorder(slaves,0,recieved-1);
   }
   end = MPI_Wtime();
   printf("\n\nExecution time = %f seconds\n",(end-start));
   MPI_Finalize();
   return 0;
}
