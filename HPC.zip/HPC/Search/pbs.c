#include<mpi.h>
#include<stdio.h>
#include<time.h>
#include<stdlib.h>


void binary_search(int *a,int left,int right,int key, int rank)
{
  while(left<=right)
  {
    int mid = (left+right)/2;
    if(a[mid]==key)
    {
      printf("Element found at index: %d, by processor: %d\n",mid,rank);
      break;
    }
    else if(key>a[mid])
     left = mid+1;
    else
     right = mid-1;
  }
}

int main(int argc, char** argv)
{
  
  int n = 1000;
  int key = 496;
  int *a = (int *)malloc(n*sizeof(int));
  for(int i=0;i<n;i++)
    a[i] = i+1;
    
  MPI_Init(&argc,&argv);
  int rank,size;
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);
  MPI_Comm_size(MPI_COMM_WORLD,&size);
  
  double start,end,cps = CLOCKS_PER_SEC;
  int blockSize = n/size;
  
  printf("Processor No: %d, Size: %d\n",rank,size);
  
  if(rank==0)
  {
    start = MPI_Wtime();
    binary_search(a,rank*blockSize,(rank+1)*blockSize-1,key,rank);
    end = MPI_Wtime();
    printf("Processor : %d, Time taken : %lf\n",rank,(end-start)*1000);
  }
  else if(rank==1)
  {
  	start = MPI_Wtime();
    binary_search(a,rank*blockSize,(rank+1)*blockSize-1,key,rank);
    end = MPI_Wtime();
    printf("Processor : %d, Time taken : %lf\n",rank,(end-start)*1000);
  }
  else if(rank==2)
  {
  	start = MPI_Wtime();
    binary_search(a,rank*blockSize,(rank+1)*blockSize-1,key,rank);
    end = MPI_Wtime();
    printf("Processor : %d, Time taken : %lf\n",rank,(end-start)*1000);
  }
  else
  {
    start = MPI_Wtime();
    binary_search(a,rank*blockSize,n-1,key,rank);
    end = MPI_Wtime();
    printf("Processor : %d, Time taken : %lf\n",rank,(end-start)*1000); 
  }
  
  MPI_Finalize();
  
  return 0;
}
