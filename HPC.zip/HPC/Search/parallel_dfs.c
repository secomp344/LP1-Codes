#include<stdio.h>
#include<mpi.h>
#include<stdlib.h>
#include<time.h>
#define send_data_tag 2001
#define return_data_tag 2002

void printInorder(int *a,int start,int end)
{
  if(start>end)
    return;
  printInorder(a,start*2+1,end);
  printf("%d ",a[start]);
  printInorder(a,start*2+2,end);
}

void buildTree(int *a,int start,int end,int *tree,int k,int offset,int n)
{
  if(start<=end && k<=n-1)
  {
  	int mid = (end+start+1)/2;
  	tree[k] = mid+offset;
  	buildTree(a,start,mid-1,tree,k*2+1,offset,n);
  	buildTree(a,mid+1,end,tree,k*2+2,offset,n);
  }
}

int main(int argc, char** argv)
{
  int n = 512;
  int a[n];
  int tree[n];
  int slaves[n];
  int turn=1;
  int children = 4;
  
  MPI_Status status;
  MPI_Init(&argc,&argv);
  int my_id,root_process = 0,n_recieved,num_process;
  MPI_Comm_rank(MPI_COMM_WORLD,&my_id);
  MPI_Comm_size(MPI_COMM_WORLD,&num_process);
  double start,end;
  start = MPI_Wtime();
  if(my_id==root_process)
  {
     for(;turn<=children;turn++)
     {
        int offset = (turn-1)*n;
        buildTree(a,0,n,tree,0,offset,n);
        MPI_Send(&n,1,MPI_INT,turn-1,send_data_tag,MPI_COMM_WORLD);
        MPI_Send(&tree,n,MPI_INT,turn-1,send_data_tag,MPI_COMM_WORLD);
     }
  }
  else
  {
    	MPI_Recv(&n_recieved,1,MPI_INT,root_process,send_data_tag,MPI_COMM_WORLD,&status);
    	int recvd = n_recieved;
    	MPI_Recv(&slaves,n,MPI_INT,root_process,send_data_tag,MPI_COMM_WORLD,&status);
    	printInorder(slaves,0,recvd-1);
  }
  end = MPI_Wtime();
  printf("\n\nExecution Time: %lf\n",(end-start));
  MPI_Finalize();
  return 0;
}
