import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GSP 
{
	List<Block> current;
	int n;
	List<Block> goals;

	public GSP(int n)
	{
		current=new ArrayList<>();
		goals=new ArrayList<>();
		this.n=n;
	}
	public static void main(String args[])
	{
		System.out.println("Enter number of blocks.");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		GSP gsp=new GSP(num);
		for(int i=0;i<gsp.n;i++)
		{
			Block b=new Block(i);
			System.out.println("Enter the block on which block "+i+" resides currently. Enter -1 for ground.");
			int z=sc.nextInt();
			if(z==i||z>=gsp.n)
			{
				System.out.println("Invalid input");
				return;
			}
			b.setOn(z);
			gsp.current.add(b);
			b=new Block(i);
			System.out.println("Enter the block on which block "+i+" resides in the goal state. Enter -1 for ground.");
			z=sc.nextInt();
			if(z==i||z>=gsp.n)
			{
				System.out.println("Invalid input");
				return;
			}
			b.setOn(z);
			gsp.goals.add(b);
		}
		gsp.satisfy();
		
	}
	public void satisfy() {
		
		boolean bool=true;
		
		while(bool)
		{
			bool=false;
			for(int i=0;i<n;i++)
			{
				if(current.get(i).getOn()!=goals.get(i).getOn())
				{
					stack(i,goals.get(i).getOn());
				}
			}
			for(int i=0;i<n;i++)
			{
				if(current.get(i).getOn()!=goals.get(i).getOn())
				{
					bool=true;
				}
			}
			
		}
		
	}
	public void stack(int i, int on) {
		clear(i);	
		if(on>=0)
		{
			clear(on);
			current.get(i).setOn(on);
			System.out.println("Stack "+i+" on "+on+".");
		}
		else
		{
			current.get(i).setOn(-1);
			System.out.println("Place "+i+" on ground.");
		}
	}
	public void clear(int id) {
		for(int i=0;i<n;i++)
		{
			if(current.get(i).getOn()==id)
			{
				clear(i);
				current.get(i).setOn(-1);
				System.out.println("Unstack "+i+" from "+id+".");
			}
		}
	}
}

class Block
{
	int on;
	int id;
	public Block(int id)
	{
		on=-1;
		this.id=id;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Block other = (Block) obj;
		if (id != other.id)
			return false;
		return true;
	}
	public int getOn() {
		return on;
	}
	public void setOn(int on) {
		this.on = on;
	}
}
